"""from Project_Main.connector import *
import tkinter as tk
from tkinter import ttk
import datetime
from calendar import monthrange"""
import datetime as datetime
from Modules import *


app = Tk()

mycursor.execute("use army")
mycursor.execute("Select * from emp")
logged = mycursor.fetchall()
a = len(logged) - 1


def search():
    id_value = (n.get() + et2.get())
    for i in logged:
        if id_value in i:
            a = logged.index(i)
    logged_data(a)


def entry():
        id = (n.get() + et2.get())
        dob = (y.get() + m.get() + day.get())
        joining_date = (date[:4] + date[4:6] + date[6:])
        print(logged)
        for i in logged:
            print(i[0])
            if i[0] == id:
                print(2)
                mycursor.execute("update emp set fname=%s,mname=%s,lname=%s,dept=%s,salary=%s ,armyrank=%s,"
                                 "age = %s ,dob=%s,doj=%s,gender=%s,code=%s,marital_status=%s,num=%s,"
                                 "address=%s where id=%s",(et4.get(), et5.get(), et6.get(), et7.get(),
                                                                    float(et8.get()), et9.get(), int(et10.get()),
                                                                    dob, joining_date, g.get(), et12.get(), ms.get(),
                                                                    et14.get(), e15.get("1.0", END), id))
                mydb.commit()
                break

        else:
            print(1)
            mycursor.execute(
                "insert into emp values('{}','{}','{}','{}','{}',{},'{}',{},'{}','{}','{}','{}','{}','{}','{}')".format(
                    id, et4.get(), et5.get(), et6.get(), et7.get(), et8.get(), et9.get(), et10.get(),
                    dob, joining_date, g.get(), et12.get(), ms.get(),
                    et14.get(),
                    e15.get("1.0", END)))
        mydb.commit()
        mb.showinfo('Sucess', 'Data Added')
        reset()



def reset():
    et2.set("")
    n.set("")
    y.set("")
    m.set("")
    d.set("")
    g.set("")
    ms.set("")
    et4.set("")
    et5.set("")
    et6.set("")
    et7.set("")
    et8.set("")
    et9.set("")
    et10.set("")
    et12.set("")
    et14.set("")
    e15.delete('1.0', END)
    day.set("")


# frm = Frame(app)
n = StringVar()
y = StringVar()
m = StringVar()
d = StringVar()
g = StringVar()
ms = StringVar()
et2 = StringVar()
et4 = StringVar()
et5 = StringVar()
et6 = StringVar()
et7 = StringVar()
et8 = StringVar()
et9 = StringVar()
et10 = StringVar()
et12 = StringVar()
et14 = StringVar()
et15 = StringVar()
day = StringVar()
date = datetime.date.today().strftime("%Y%m%d")
my_date = datetime.datetime.strptime(date, "%Y%m%d")
current_year = my_date.year
current_month = my_date.month


def getday():
    a = int(y.get())
    b = int(m.get())
    days = monthrange(a, b)
    days = [*range(1, days[1] + 1)]
    for i in days:
        if i < 10:
            index = days.index(i)
            i = "0"+str(i)
            days[index] = i
    ttk.Combobox(frame3, width=5, textvariable=day, values=days, state="readonly").grid(row=0, column=3)


def logged_data(a):
    e1, e3, e4, e5, e6, e7, e8, e9, e10, ee, e11, e12, e13, e14, ee15 = logged[a]
    e10 = e10.strftime("%Y%m%d")
    et2.set(e1[2:])
    n.set(e1[:2])
    y.set(e10[:4])
    m.set(e10[4:6])
    day.set(e10[6:])
    g.set(e11)
    ms.set(e13)
    et4.set(e3)
    et5.set(e4)
    et6.set(e5)
    et7.set(e6)
    et8.set(e7)
    et9.set(e8)
    et10.set(e9)
    et12.set(e12)
    et14.set(e14)
    asd()
    e15.insert(END, ee15)


def next():
    global a
    if a < len(logged) - 1:
        a += 1
        logged_data(a)
    else:
        mb.showinfo('End', 'No more Records\nto Display')


def asd():
    e15.delete("1.0", END)


def back():
    global a
    if a >= 0:
        a -= 1
        logged_data(a)
    else:
        mb.showinfo('End', 'The End of Table Records')


def home():
    app.destroy()
    os.system("Python Home_Page.py")


label1 = ttk.Label(app, text="Add On Information", foreground="#138D75",
                   font=("Times New Roman", 30)).grid(row=0, column=2)

frame1 = Frame(app)
frame1.grid(row=1, column=1)

ids = ttk.Combobox(frame1, width=3, textvariable=n, state="readonly")
ids['values'] = ('AF', 'AR', 'ME', 'NV')
ids.grid(row=0, column=0)

label2 = ttk.Label(app, text="ID", foreground="#632BE1",
                   font=("Times New Roman", 15)).grid(row=1, column=0)

e2 = ttk.Entry(frame1, textvariable=et2).grid(row=0, column=1)

label3 = ttk.Label(app, text="Name:~", background='orange', foreground="white",
                   font=("Times New Roman", 15)).grid(row=2, column=0)



label4 = ttk.Label(app, text="First",
                   foreground="#632BE1",
                   font=("Times New Roman", 15)).grid(row=3, column=0)
e4 = ttk.Entry(app, textvariable=et4).grid(row=3, column=1)

label5 = ttk.Label(app, text="Second",
                   foreground="#632BE1",
                   font=("Times New Roman", 15)).grid(row=4, column=0)
e5 = ttk.Entry(app, textvariable=et5).grid(row=4, column=1)

label6 = ttk.Label(app, text="Last",
                   foreground="#632BE1",
                   font=("Times New Roman", 15)).grid(row=5, column=0)
e6 = ttk.Entry(app, textvariable=et6).grid(row=5, column=1)

label7 = ttk.Label(app, text="Department",
                   foreground="#632BE1",
                   font=("Times New Roman", 15)).grid(row=7, column=0)
e7 = ttk.Entry(app, textvariable=et7).grid(row=7, column=1)

label8 = ttk.Label(app, text="Salary",
                   foreground="#632BE1",
                   font=("Times New Roman", 15)).grid(row=8, column=0)
e8 = ttk.Entry(app, textvariable=et8, width=15).grid(row=8, column=1)

label9 = ttk.Label(app, text="Army Rank",
                   foreground="#632BE1",
                   font=("Times New Roman", 15)).grid(row=1, column=3)
e9 = ttk.Entry(app, textvariable=et9).grid(row=1, column=4)

label10 = ttk.Label(app, text="Age",
                    foreground="#632BE1",
                    font=("Times New Roman", 15)).grid(row=2, column=3)
e10 = ttk.Entry(app, textvariable=et10).grid(row=2, column=4)

label11 = ttk.Label(app, text="Gender",
                    foreground="#632BE1",
                    font=("Times New Roman", 15)).grid(row=3, column=3)
gender = ttk.Combobox(app, width=7, textvariable=g, state="readonly", values=('M', 'F', 'T'))
gender.grid(row=3, column=4)

label12 = ttk.Label(app, text="Code",
                    foreground="#632BE1",
                    font=("Times New Roman", 15)).grid(row=4, column=3)
e12 = ttk.Entry(app, textvariable=et12).grid(row=4, column=4)

label13 = ttk.Label(app, text="Marital Status",
                    foreground="#632BE1",
                    font=("Times New Roman", 15)).grid(row=5, column=3)
marital_status = ttk.Combobox(app, width=7, textvariable=ms, state="readonly", values=('M', 'S'))
marital_status.grid(row=5, column=4)

label14 = ttk.Label(app, text="Number",
                    foreground="#632BE1",
                    font=("Times New Roman", 15)).grid(row=6, column=3)
e14 = ttk.Entry(app, textvariable=et14).grid(row=6, column=4)

label15 = ttk.Label(app, text="Address",
                    foreground="#632BE1",
                    font=("Times New Roman", 15)).grid(row=7, column=3)

e15 = scrolledtext.ScrolledText(app, undo=True, width=30, height=5, wrap=tk.WORD)
e15['font'] = ('consolas', '12')
e15.grid(row=7, column=4)

frame3 = Frame(app)
frame3.grid(row=9, column=2)

label16 = ttk.Label(app, text="DOB",
                    background='orange', foreground="white",
                    font=("Times New Roman", 15)).grid(row=9, column=1)

years = [*range(current_year - 150, current_year + 1, 1)]
year = ttk.Combobox(frame3, width=10, textvariable=y, state="readonly", values=years, postcommand=getday)
year.grid(row=0, column=0, padx=5)

months = [*range(1, current_month + 1)]
for i in months:
    if i < 10:
        index = months.index(i)
        i = "0" + str(i)
        months[index] = i
month = ttk.Combobox(frame3, width=5, textvariable=m, values=months, state="readonly", postcommand=getday)
month.grid(row=0, column=1, padx=5)

ids.current()
year.current(150)
month.current(0)
getday()

s = ttk.Style()
s.configure('my.TButton', font=('Helvetica', 15), foreground='red', )

home_button = ttk.Button(app, text="Home Page", command=home, style='my.TButton', )
home_button.grid(row=9, column=4)

entry_button = ttk.Button(app, text="Entry", command=entry, style='my.TButton')
entry_button.grid(row=10, column=4)

next_button = ttk.Button(app, text="< Next", command=next, style='my.TButton')
next_button.grid(row=11, column=3)

back_button = ttk.Button(app, text="Back >", command=back, style='my.TButton')
back_button.grid(row=11, column=4)

reset_button = ttk.Button(app, text="Reset", command=reset, style='my.TButton')
reset_button.grid(row=10, column=3)

back_button = ttk.Button(app, text="Search", command=search)
back_button.grid(row=1, column=2)





def center_window(width, height):
    # get screen width and height
    screen_width = app.winfo_screenwidth()
    screen_height = app.winfo_screenheight()

    # calculate position x and y coordinates
    x = (screen_width / 2) - (width / 2)
    y = (screen_height / 2) - (height / 2)
    app.geometry('%dx%d+%d+%d' % (width, height, x, y))


center_window(1050, 450)
app.resizable(False, False)
app.mainloop()

