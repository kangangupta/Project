"""import tkinter as tk
from tkinter import ttk
import os"""
from Modules import *
app = Tk()

'''photo = PhotoImage(file="home_page_icon.jpg")
app.iconphoto(False, photo)'''



def emp_table():
    app.destroy()
    os.system("Python emp_Table.py")


def products_table():
    app.destroy()
    os.system("Python products_Table.py")


def supplies_table():
    app.destroy()
    os.system("Python supplies_Table.py")


def camp_table():
    app.destroy()
    os.system("Python camp_Table.py")


def emp_add_data():
    app.destroy()
    os.system("Python Emp_Add_Data.py")


s = ttk.Style()
s.configure('my.TButton', font=('Helvetica', 15), foreground='black',background="#0A4438")


image=Image.open("a2.jpg")
image2=Image.open("a1.png")
image=image.resize((180,200))
image2=image2.resize((190,200))
photo=ImageTk.PhotoImage(image)
photo2=ImageTk.PhotoImage(image2)

pic=Label(image=photo)
pic.pack()
pic.place(relx=0.7,rely=0.6,anchor="w")

pic1=Label(image=photo2)
pic1.pack()
pic1.place(relx=0.35,rely=0.6,anchor="e")




label = ttk.Label(app, text="Militiary Services", foreground="Black", font=("Arial Rounded MT Bold", 38)).grid(row=0,
                                                                                                               column=0,
                                                                                                               padx=150)                                                                                                              

a = home_page()

if a >= 0:
    b1 = ttk.Button(app, text="Employee", command=emp_table, style='my.TButton').grid(row=1, column=0, pady=10)
    b2 = ttk.Button(app, text="Products", command=products_table, style='my.TButton').grid(row=2, column=0)
    if a >= 1:
        b3 = ttk.Button(app, text="Supplies", command=supplies_table, style='my.TButton').grid(row=3, column=0, pady=10)
        b4 = ttk.Button(app, text="Camps", command=camp_table, style='my.TButton').grid(row=4, column=0)
        if a >= 2:
            b5 = ttk.Button(app, text="Add Data", command=emp_add_data, style='my.TButton').grid(row=4, column=0)

def sign_out():
    app.destroy()
    os.system("python Login_Page.py")


b6 = ttk.Button(app, text="Sign Out", command=sign_out,
                style='my.TButton').grid(row=6, column=0, pady=10)


def center_window(width, height):
    # get screen width and height
    screen_width = app.winfo_screenwidth()
    screen_height = app.winfo_screenheight()

    # calculate position x and y coordinates
    x = (screen_width / 2) - (width / 2)
    y = (screen_height / 2) - (height / 2)
    app.geometry('%dx%d+%d+%d' % (width, height, x, y))


center_window(700, 300)




app.resizable(False, False)
app.configure(bg='#0A4438')
app.config(highlightbackground="#053128",highlightthickness=10,highlightcolor="#053128")
app.mainloop()
