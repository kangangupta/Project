"""from Project_Main.connector import *
from tkinter import *
from tkinter import messagebox as mb
from tkinter import ttk
import os"""
from Modules import *


app = Tk()
photo = PhotoImage(file="log_in_icon.png")
app.iconphoto(False, photo)
app.configure(bg="#0A4438")
mycursor.execute("use army")


try:
    mycursor.execute('CREATE VIEW logged AS SELECT fname, id FROM emp')
except:
    mycursor.execute('Select * from logged')

logged = mycursor.fetchall()
mycursor.execute('Select * from access')
access = mycursor.fetchall()
print(logged)

logged_in = 0


def reset():
    username.delete(0, END)
    password.delete(0, END)


app.title("Login Page")


l1 = Label(app, text='Username', pady=5, bg="#0A4438",fg="white", font=("Arial", 15)).grid(row=0, column=0)
l2 = Label(app, text='Password', pady=5, bg="#0A4438",fg="white", font=("Arial", 15)).grid(row=1, column=0)
username = ttk.Entry(app)
username.grid(row=0, column=1)
password = ttk.Entry(app, show="*")
password.grid(row=1, column=1)
frame = Frame(app)
frame.grid(row=3, columnspan=2)
b1 = ttk.Button(frame, text="Enter",command=lambda: logging_in(username, password, logged, access, app)).grid(row=0,
                                                                                                               column=0,
                                                                                                               padx=10)
b2 = ttk.Button(frame, text="Reset", command=reset).grid(row=0, column=1)


def center_window(width, height):
    # get screen width and height
    screen_width = app.winfo_screenwidth()
    screen_height = app.winfo_screenheight()

    # calculate position x and y coordinates
    x = (screen_width / 2) - (width / 2)
    y = (screen_height / 2) - (height / 2)
    app.geometry('%dx%d+%d+%d' % (width, height, x, y))


center_window(250, 100)
app.resizable(False, False)
app.mainloop()
# msg.setDetailedText("Username or Password Entered is Wrong.\nIt is Case Sensitive!!!")
