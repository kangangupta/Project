from tkinter import ttk
import tkinter as tk
import os
from tkinter import *
import mysql.connector
from tkinter import Tk
from tkinter import Frame
from tkinter import PhotoImage
from tkinter import messagebox as mb
import datetime
from calendar import monthrange
import tkinter.scrolledtext as scrolledtext
from PIL import Image,ImageTk

def logging_in(username, password, logged, access, app):
    u = username.get()
    p = password.get()
    for i in logged:
        if u == "" or p == "":
            mb.showerror('ERROR', 'Please Completely fill\nBoth the Fields')
            break
        elif i[0] == u and i[1] == p:
            mb.showinfo('Sucess', 'You are Logged in')
            for i in access:
                if i[0] == p:
                    access_no = i[1]
                    app.destroy()
                    access_key(access_no)
                    os.system("python Home_Page.py")
            break
    else:
        mb.showwarning('Failed', 'Failed to Sign IN')


def access_key(access_no):
    file = open("access_key.txt", 'w')
    file.write(str(access_no))
    file.close()

def home_page():
    file = open("access_key.txt", 'r')
    a = file.readline()
    file.close()
    return int(a)


mydb = mysql.connector.connect(
    host="localhost",
    user="user",
    password="password",
    auth_plugin='mysql_native_password',
)

mycursor = mydb.cursor(buffered=True)
