import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="user",
    password="password",
    auth_plugin='mysql_native_password',
)

print(mydb)

mycursor = mydb.cursor(buffered=True)

mycursor.execute("SHOW DATABASES")
mycursor.execute("drop database army")




