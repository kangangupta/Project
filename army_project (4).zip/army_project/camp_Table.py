# Python program to illustrate the usage of
# treeview scrollbars using tkinter


"""from tkinter import ttk
import tkinter as tk
from Project_Main.connector import *
#from Main.Connector1 import *"""
from Modules import *

mydb = mysql.connector.connect(
    host="localhost",
    user="user",
    password="password",
    auth_plugin='mysql_native_password',
)


mycursor = mydb.cursor(buffered=True)
mycursor.execute("use army")
mycursor.execute('Select * from camp')
logged = mycursor.fetchall()

# Creating tkinter window
window = Tk()
window.resizable(width=1, height=1)
window.configure(bg='#0A4438')

# Using treeview widget
treev = ttk.Treeview(window, selectmode='browse', height="20")

# Calling pack method w.r.to treeview
treev.pack(side='right')

# Constructing vertical scrollbar
# with treeview
verscrlbar = ttk.Scrollbar(window,
                           orient="vertical",
                           command=treev.yview)

# Calling pack method w.r.to verical
# scrollbar
verscrlbar.pack(side='right', fill='x')

# Configuring treeview
treev.configure(xscrollcommand=verscrlbar.set)
"""

hscrlbar = ttk.Scrollbar(window,
                           orient="horizontal",
                           command=treev.xview)

hscrlbar.pack(side='bottom', fill='y')

# Configuring treeview
treev.configure(xscrollcommand=hscrlbar.set)"""


# Defining number of columns
treev["columns"] = ("1", "2", "3", "4")

# Defining heading
treev['show'] = 'headings'

# Assigning the width and anchor to the
# respective columns
treev.column("1", width=90, anchor='c')
treev.column("2", width=200, anchor='c')
treev.column("3", width=90, anchor='se')
treev.column("4", width=250, anchor='c')


# Assigning the heading names to the
# respective columns
treev.heading("1", text="City")
treev.heading("2", text="State")
treev.heading("3", text="Code")
treev.heading("4", text="Name of Institution")

for i in logged:
    a, b, c, d= i
    treev.insert("", 'end', text="L1",
                 values=(a, b, c, d))

def back():
    window.destroy()
    os.system("Python Home_Page.py")


back_button = ttk.Button(window, text="Back", command=back)
back_button.pack(side="bottom")
window.resizable(width=False, height=False)
# Calling mainloop
window.mainloop()
