import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="user",
    password="password",
    auth_plugin='mysql_native_password',
)

print(mydb)

mycursor = mydb.cursor(buffered=True)

mycursor.execute("SHOW DATABASES")

x = ("army",)

if x in mycursor:
    mycursor.execute("use army")
else:
    mycursor.execute("CREATE DATABASE army")
    mycursor.execute("use army")

    table1 = 'create table emp(id varchar(9) not null primary key,fname varchar(20),mname varchar(20),lname varchar(20),' \
                 'dept varchar(25) ,salary float,armyrank varchar(25),age smallint,dob date,doj date,gender char(1), code varchar (' \
                 '8),marital_status char(1), num varchar(15), address varchar(100))'
    mycursor.execute(table1)

    table2 = 'create table camp(city varchar(20),state varchar(20),code varchar(8) not null primary key,nameofInst varchar(20))'
    mycursor.execute(table2)

    table3 = 'create table supplies(code varchar(8),product_id varchar(6),quantity smallint,supplier varchar(30))'
    mycursor.execute(table3)

    table4 = 'create table products(product_id varchar(6) not null primary key,product varchar(30),type varchar(15))'
    mycursor.execute(table4)

    table5 = 'create table desig(armyrank varchar(40), department varchar(5), access int)'
    mycursor.execute(table5)

    mycursor.execute('Create view access as select emp.id, desig.access from emp, desig where emp.armyrank = desig.armyrank '
                     'and (substring(emp.id, 1, 2) = desig.department or desig.department is NULL)')

    data1 = {
        "insert into emp values('AF7645784','Amita',NULL,'Gupta','Air Force',134000.00,'Air Commodore',30,'1990-05-08','2015-06-08','F','KO682001','S','9811056289','W-186 sec-12 near new condly Punjab')",

        "insert into emp values('AR3787675','Nitin',NULL,'Jain','Army',250000.00,'General',55,'1965-06-26','1995-07-09','F','GA823001','M','9910006289','194,ST Road 2 Punjab')",

        "insert into emp values('ME9755776','Abhay',NULL,'Nanda','Medical',254000.00,'Surgeon',51,'1969-07-25','1994-05-06','M','NE524001','M','8744988795','A-203,second floor, near IG park Noida')",

        "insert into emp values('NV3456677','Ramesh',NULL,'Agarwal','Navy',200500.00,'Vice Admiral',46,'1974-08-16','1999-07-08','M','GU781001','S','9911179166','205 Aashirwad Apartments near GIP, Noida')",

        "insert into emp values('AR3556778','Kiya',NULL,'Gureja','Army',70000.00,'Lieutenant',24	,'1996-01-18','2016-07-08','F','GA823001','S','9856471230','B-132,Mayur Vihar phase 3 noida')",

        "insert into emp values('AR8567888','Arvind',NULL,'Dutta','Army',180000.00,'Colonel',57,'1963-09-16','1999-12-25','M','BI495001','M','8753694120','C-76 Stellar jeewan, Greater noida')",

        "insert into emp values('NV5774573','Anil','Kumar','Sharma','Navy',154200.00,'Rear Admiral',42,'1978-04-04','2000-01-02','M','VA300018','M','8756499321','A-65,New Kondli Ghaziabad')",

        "insert into emp values('AF2456782','Tejender',NULL,'Singh','Air Force',205500.00,'Air Marshal',55,'1965-05-01','1998-02-03','M','SO173211','M','9548231709','M-42, Gokul society near SBS mall Pitampura')",

        "insert into emp values('NV6568781','Sanjeev','Pratap','Shrivastava','Navy',225000.00,'Admiral',56,'1964-08-02','1997-03-06','M','JM831001','M','7895214630','21 beta road race course Delhi')",

        "insert into emp values('AF4265670','Mohit',NULL,'Bhalla','Air Force',116700.00,'Wing Commander',49,'1971-07-03','1996-06-05','M','KO682001','M','8569471230','N-79 road 12, vasundhara delhi')",

        "insert into emp values('NV4667879','Ketan',NULL,'Bhat','Navy',218200.00,'Rear Admiral',32,'1988-06-22','2005-08-08','M','MA676504','S','6589074123','O-22,sec 34 Kochi kerala')",

        "insert into emp values('AR3456787','Priya',NULL,'Chopra','Army',456000.00,'Lieutenant General',46,'1974-05-17','1993-09-12','F','PU411004','M','8079654122','H-77, Sec-65, Pune')",

        "insert into emp values('AF5364689','Gunjan',NULL,'Saxena','Air Force',69400.00,'Squadron Leader',29,'1991-12-26','2010-10-06','F','RO769001','S','9975886324','G-36, RamSita apartments, road 45 Madhya Pradesh')",

        "insert into emp values('NV6586879','Abhay',NULL,'Chopra','Navy',140600.00,'Commodore',52,'1968-02-28','1992-11-23','M','DU713025','M','9840563277','I-90, patparganj, Ghaziabad Delhi')",

        "insert into emp values('AR4258689','Sonali',NULL,'Manhotra','Army',68100.00,'Lieutenant',28,'1992-06-27','2014-11-02','F','MA676504','S','9875565354','D-4, NEW Colony ahmedabad, Gujrat')",

        "insert into emp values('ME4354678','Mahira',NULL,'Verma','Medical',84400.00,'Physician' ,30,'1990-10-29','2015-12-03','F','GA823001','S','9875465658','U-75 Ashoka Greens, patna Bihar')",
    }

    data2 = {
        "insert into camp values('Nellore','Andhra pradesh','NE524001','Taurus station')",
        "insert into camp values('Guwhati','Assam','GU781001','Sarvatra CSD')",
        "insert into camp values('Gaya','Bihar','GA823001','CASD CSD')",
        "insert into camp values('Bilaspur','Chattisgarh','BI495001','Camero AF')",
        "insert into camp values('Vadodra','Gujarat','VA300018','Pinto Park CSD')",
        "insert into camp values('Solan','Himachal pradesh', 'SO173211','Topchee')",
        "insert into camp values('Jamshedpur','Jharkhand','JM831001','Vajra CSD')",
        "insert into camp values('Kochi','Kerela','KO682001','Golden Lion')",
        "insert into camp values('Malappuram','Kerela','MA676504','C.A.F.V.D.')",
        "insert into camp values('Pune','Maharashtra', 'PU411004','Coast Guard CSD')",
        "insert into camp values('Rourkela','Odisha','RO769001','Southern Air Command')",
        "insert into camp values('Durgapur','West bengal','DU713025','Bison Unit Run')",
    }

    data3 = {
        "insert into supplies values('NE524001','AR0011',25,'Radar Gun Corp.')",
        "insert into supplies values('GU781001','ME0008',50,'Healing Touch Pharmacy')",
        "insert into supplies values('DU713025','AR0003',15,'Protect Me Corp. Ltd.')",
        "insert into supplies values('BI495001','ME0004',20,'Sunrise Medical Services')",
        "insert into supplies values('VA300018','ME0007',22,'Bloom Medical Services')",
        "insert into supplies values('NE524001','AR0008',15,'Sunrise Medical Services')",
        "insert into supplies values('KO682001','AR0010',15,'Ammunition Ltd.')",
        "insert into supplies values('MA676504','FD0001',50,'Rainbow Food Services')",
        "insert into supplies values('DU713025','FD0002',50,'Rainbow Food Services')",
        "insert into supplies values('BI495001','FD0005',30,'Ostar Food Services')",
        "insert into supplies values('PU411004','AR0007',30,'Protect Me Corp. Ltd.')",
        "insert into supplies values('KO682001','FD0004',35,'Foreign DERS Food Services')",
        "insert into supplies values('JM831001','AR0006',12,'Ammunition Ltd.')",
        "insert into supplies values('VA300018','AR0012',20,'Protect Me Corp. Ltd.')",
        "insert into supplies values('JM831001','ME0003',16,'Career Pharmacy')",
    }

    data4 = {
        "insert into products VALUES('AR0001','Pistol Auto 9mm 1A','Arsenal')",
        "insert into products VALUES('AR0002','Micro-Uzi','Arsenal')",
        "insert into products VALUES('AR0003','Heckler & Koch MP5','Arsenal')",
        "insert into products VALUES('AR0004','AKM','Arsenal')",
        "insert into products VALUES('AR0005','AK-103','Arsenal')",
        "insert into products VALUES('AR0006','M16 rifle','Arsenal')",
        "insert into products VALUES('AR0007','M4A1 Carbine','Arsenal')",
        "insert into products VALUES('AR0008','Glock 19','Arsenal')",
        "insert into products VALUES('AR0009','Mauser SP66','Arsenal')",
        "insert into products VALUES('AR0010','Grenade 36mm','Arsenal')",
        "insert into products VALUES('AR0011','AGS-17 Plamya','Arsenal')",
        "insert into products VALUES('AR0012','AK-203','Arsenal')",
        "insert into products VALUES('ME0001','Cravats','Medical')",
        "insert into products VALUES('ME0002','Safety Pins','Medical')",
        "insert into products VALUES('ME0003','Gloves','Medical')",
        "insert into products VALUES('ME0004','Band-Aids','Medical')",
        "insert into products VALUES('ME0005','Alcohol','Medical')",
        "insert into products VALUES('ME0006','Assorted Hypodermic Needles','Medical')",
        "insert into products VALUES('ME0007','Morphine','Medical')",
        "insert into products VALUES('ME0008','Antibiotics','Medical')",
        "insert into products VALUES('ME0009','Acetaminophen','Medical')",
        "insert into products VALUES('ME0010','Docusate','Medical')",
        "insert into products VALUES('FD0001','Nutrition Food Bars','Food')",
        "insert into products VALUES('FD0002','Processed Chapatis','Food')",
        "insert into products VALUES('FD0003','Dry Nuts','Food')",
        "insert into products VALUES('FD0004','Canned Dal','Food')",
        "insert into products VALUES('FD0005','Canned Beans','Food')",
        "insert into products VALUES('FD0006','MREsFood','Food')",
        "insert into products VALUES('FD0007','Performance Enhancement Drink','Food')",
        "insert into products VALUES('FD0008','Dry Fruits','Food')",

    }

    data5 = {
        "insert into desig values('General','AR',0)",
        "insert into desig values('Lieutenant General','AR',0)",
        "insert into desig values('Major General','AR',0)",
        "insert into desig values('Brigadier','AR',0)",
        "insert into desig values('Colonel','AR',0)",
        "insert into desig values('Lieutenant Colonel','AR',1)",
        "insert into desig values('Major','AR',1)",
        "insert into desig values('Captain','AR',1)",
        "insert into desig values('Lieutenant','AR',2)",
        "insert into desig values('Air Chief Marshal','AF',0)",
        "insert into desig values('Air Marshal','AF',0)",
        "insert into desig values('Air Vice Marshal','AF',0)",
        "insert into desig values('Air Commodore','AF',0)",
        "insert into desig values('Group Captain','AF',1)",
        "insert into desig values('Wing Commander','AF',1)",
        "insert into desig values('Squadron Leader','AF',1)",
        "insert into desig values('Fight Lieutenant','AF',2)",
        "insert into desig values('Flying Officer','AF',2)",
        "insert into desig values('Admiral','NV',0)",
        "insert into desig values('Vice Admiral','NV',0)",
        "insert into desig values('Rear Admiral','NV',0)",
        "insert into desig values('Commodore','NV',0)",
        "insert into desig values('Captain','NV',1)",
        "insert into desig values('Commander','NV',1)",
        "insert into desig values('Lieutenant Commander','NV',1)",
        "insert into desig values('Lieutenant','NV',2)",
        "insert into desig values('Sublieutenant','NV',2)",
        "insert into desig values('Admin1',Null,2)",
        "insert into desig values('Admin2', Null ,2)",
    }

    for i in data1:
        mycursor.execute(i)

    for i in data2:
        mycursor.execute(i)

    for i in data3:
        mycursor.execute(i)

    for i in data4:
        mycursor.execute(i)

    for i in data5:
        mycursor.execute(i)


mydb.commit()
mycursor.close()
mydb.close()
print("DONE")
"""select emp.id,desig.access from emp, desig
where emp.armyrank = desig.designation and substring(emp.id, 1, 2) = desig.department or desig.department = NULL ;"""
