# Python program to illustrate the usage of
# treeview scrollbars using tkinter


"""from tkinter import ttk
import tkinter as tk
from Project_Main.connector import *
import os"""
from Modules import *

mydb = mysql.connector.connect(
    host="localhost",
    user="user",
    password="password",
    auth_plugin='mysql_native_password',
)

print(mydb)

mycursor = mydb.cursor(buffered=True)
mycursor.execute("use army")
mycursor.execute('Select * from emp')
logged = mycursor.fetchall()

# Creating tkinter window
window = Tk()
window.resizable(False, False)
window.configure(bg="#0A4438")
separator = PanedWindow(window, bd=0, bg="#202322", sashwidth=2)

separator.pack(fill=BOTH, expand=1)

# Using treeview widget
treev = ttk.Treeview(window, selectmode='browse', height="20")

# Calling pack method w.r.to treevie

_frame = Frame(window, bg="#383838")

t = ttk.Treeview(_frame)
# Configuring treeview
ysb = ttk.Scrollbar(orient=VERTICAL, command=t.yview)
xsb = ttk.Scrollbar(orient=HORIZONTAL, command=t.xview)
t['yscroll'] = ysb.set
t['xscroll'] = xsb.set

# Defining number of columns
t["columns"] = ("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15")

# Defining heading
t['show'] = 'headings'

# Assigning the width and anchor to the
# respective columns
t.column("1", width=90, anchor='c')
t.column("2", width=90, anchor='se')
t.column("3", width=90, anchor='se')
t.column("4", width=90, anchor='se')
t.column("5", width=90, anchor='se')
t.column("6", width=100, anchor='se')
t.column("7", width=150, anchor='se')
t.column("8", width=90, anchor='c')
t.column("9", width=90, anchor='se')
t.column("10", width=90, anchor='se')
t.column("11", width=80, anchor='c')
t.column("12", width=90, anchor='se')
t.column("13", width=90, anchor='c')
t.column("14", width=120, anchor='se')
t.column("15", width=400, anchor='sw')

# Assigning the heading names to the
# respective columns
t.heading("1", text="ID")
t.heading("2", text="First Name")
t.heading("3", text="Middle Name")
t.heading("4", text="Last Name")
t.heading("5", text="Department")
t.heading("6", text="Salary")
t.heading("7", text="Rank")
t.heading("8", text="Age")
t.heading("9", text="DOB")
t.heading("10", text="DOJ")
t.heading("11", text="Gender")
t.heading("12", text="Code")
t.heading("13", text="Marital Status")
t.heading("14", text="Number")
t.heading("15", text="Address")

to_find = StringVar()
field = StringVar()


def delete_data():
    x = t.get_children()
    for row_id in x:
        t.delete(row_id)


if to_find.get() == "" and field.get() == "":
    delete_data()
    for i in logged:
        a, b, c, d, e, f, g, h, i, j, k, l, m, n, o = i
        t.insert("", 'end', text="L1",
                 values=(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o))


def search():
    to_find1 = to_find.get()
    field1 = field.get()
    field_dic = {"ID": "id", "First Name": "fname", "Middle Name": "mname", "Last Name": "lname", "Department": "dept",
                 "Salary": "salary", "Army Rank": "armyrank", "Age": "age", "Date of Birth": "dob",
                 "Date of Joining": "doj", "Gender": "gender", "Code": "code",
                 "Marital Status": "marital_status", "Number": "num", "Address": "address"}
    if to_find.get() != "" and field.get() != "":
        field1 = field_dic[field1]
        delete_data()
        mycursor.execute("select * from emp where %s = '%s'" % (field1, to_find1))
        asd = mycursor.fetchall()
        for i in asd:
            a, b, c, d, e, f, g, h, i, j, k, l, m, n, o = i
            t.insert("", 'end', text="L1",
                     values=(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o))
    elif to_find1 != "" and field1 == "" :
        delete_data()
        mycursor.execute("select * from emp")
        asd = mycursor.fetchall()
        for i in asd:
            if to_find1 in i:
                a, b, c, d, e, f, g, h, i, j, k, l, m, n, o = i
                t.insert("", 'end', text="L1",
                         values=(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o))


ttk.Entry(window, textvariable=to_find).pack(side="bottom")
fields = ["ID", "First Name", "Middle Name", "Last Name", "Department", "Salary", "Army Rank", "Age", "Date of Birth",
          "Date of Joining", "Gender", "Code",
          "Marital Status", "Number", "Address"]
ttk.Combobox(window, width=30, textvariable=field, state="readonly", values=fields).pack(side='left')

btn2=Button(window,text="Search",command=search,width=10)
btn2.pack()
btn2.place(x=350,y=354)

def back():
    window.destroy()
    os.system("Python Home_Page.py")


t.grid(in_=_frame, row=0, column=0, sticky=NSEW)
ysb.grid(in_=_frame, row=0, column=1, sticky=NS)
xsb.grid(in_=_frame, row=1, column=0, sticky=EW)
_frame.rowconfigure(0, weight=1)
_frame.columnconfigure(0, weight=1)

separator.add(_frame)

back_button = ttk.Button(window, text="Back",width=20, command=back)
back_button.pack(side="right")

def center_window(width, height):
    # get screen width and height
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()

    # calculate position x and y coordinates
    x = (screen_width / 2) - (width / 2)
    y = (screen_height / 2) - (height / 2)
    window.geometry('%dx%d+%d+%d' % (width, height, x, y))


center_window(800, 400)
window.mainloop()
