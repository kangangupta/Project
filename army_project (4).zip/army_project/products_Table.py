# Python program to illustrate the usage of
# treeview scrollbars using tkinter


"""from tkinter import ttk
import tkinter as tk
from Project_Main.connector import *
import os
#from Main.connector import *"""
from Modules import *

mydb = mysql.connector.connect(
    host="localhost",
    user="user",
    password="password",
    auth_plugin='mysql_native_password',
)


mycursor = mydb.cursor(buffered=True)
mycursor.execute("use army")
mycursor.execute('Select * from products')
logged = mycursor.fetchall()

# Creating tkinter window
window = Tk()
window.resizable(False, False)
window.configure(bg='#0A4438')

# Using treeview widget
treev = ttk.Treeview(window, selectmode='browse', height="20")

# Calling pack method w.r.to treeview
treev.pack(side='right')

# Constructing vertical scrollbar
# with treeview
verscrlbar = ttk.Scrollbar(window,
                           orient="vertical",
                           command=treev.yview)

# Calling pack method w.r.to verical
# scrollbar
verscrlbar.pack(side='right', fill='x')

# Configuring treeview
treev.configure(xscrollcommand=verscrlbar.set)

# Defining number of columns
treev["columns"] = ("1", "2", "3")

# Defining heading
treev['show'] = 'headings'

# Assigning the width and anchor to the
# respective columns

treev.column("1", width=120, anchor='c')
treev.column("2", width=200, anchor='se')
treev.column("3", width=90, anchor='se')

# Assigning the heading names to the
# respective columns
style=ttk.Style()
style.configure("Treeview.Heading",font=("Times",16,"bold italic"))
treev.heading("1", text="Product_ID")
treev.heading("2", text="Product")
treev.heading("3", text="Type")

iid = 0
deleted = []
dic1 = {}

for i in logged:
    a, b, c = i
    treev.insert("", 'end', text="L1", iid=iid,
                 values=(a, b, c))
    dic1[iid] = a
    iid += 1


def delete_data():
    row_id = int(treev.focus())
    treev.delete(row_id)
    deleted.append(row_id)


def save():
    for i in deleted:
        a = dic1[i]
        mycursor.execute("DELETE FROM products WHERE Product_ID = '{}'".format(a))
        print("Deleted", a)
    mydb.commit()


def back():
    window.destroy()
    os.system("Python Home_Page.py")


frame = Frame(window)
frame.pack(side="bottom")

frame1 = Frame(window)
frame1.pack(side="bottom")


delete_button = ttk.Button(frame1, text="Delete", command=delete_data)
delete_button.grid(row=0, column=2)

save_button = ttk.Button(frame, text="Save", command=save)
save_button.grid(row=1, column=1)

back_button = ttk.Button(frame, text="Back", command=back)
back_button.grid(row=1, column=3)

def center_window(width, height):
    # get screen width and height
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()

    # calculate position x and y coordinates
    x = (screen_width / 2) - (width / 2)
    y = (screen_height / 2) - (height / 2)
    window.geometry('%dx%d+%d+%d' % (width, height, x, y))


center_window(600, 400)
window.mainloop()
