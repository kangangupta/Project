# Python program to illustrate the usage of
# treeview scrollbars using tkinter


"""from tkinter import ttk
import tkinter as tk
from Project_Main.connector import *"""
from Modules import *

# from Main.Connector1 import *

mydb = mysql.connector.connect(
    host="localhost",
    user="user",
    password="password",
    auth_plugin='mysql_native_password',
)

mycursor = mydb.cursor(buffered=True)
mycursor.execute("use army")
mycursor.execute('Select * from supplies')
logged = mycursor.fetchall()

# Creating tkinter window
window = Tk()
window.resizable(False, False)

# Using treeview widget
treev = ttk.Treeview(window, selectmode='browse', height="20")



# Calling pack method w.r.to treeview
treev.pack(side='right')

# Constructing vertical scrollbar
# with treeview
verscrlbar = ttk.Scrollbar(window,
                           orient="vertical",
                           command=treev.yview)

# Calling pack method w.r.to verical
# scrollbar
verscrlbar.pack(side='right', fill='x')

# Configuring treeview
treev.configure(xscrollcommand=verscrlbar.set)

# Defining number of columns
treev["columns"] = ("1", "2", "3", "4")

# Defining heading
treev['show'] = 'headings'

# Assigning the width and anchor to the
# respective columns
treev.column("1", width=90, anchor='c')
treev.column("2", width=150, anchor='c')
treev.column("3", width=90, anchor='c')
treev.column("4", width=250, anchor='c')

# Assigning the heading names to the
# respective columns
treev.heading("1", text="Code")
treev.heading("2", text="Product_ID")
treev.heading("3", text="Quantity")
treev.heading("4", text="Supplier")
a = ttk.Style().configure("treev", background="#383838")
for i in logged:
    a, b, c, d = i
    treev.insert("", 'end', text="L1",
                     values=(a, b, c, d), tags='Placed')


def back():
    window.destroy()
    os.system("Python Home_Page.py")


back_button = ttk.Button(window, text="Back", command=back)
back_button.pack(side="bottom")
def center_window(width, height):
    # get screen width and height
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()

    # calculate position x and y coordinates
    x = (screen_width / 2) - (width / 2)
    y = (screen_height / 2) - (height / 2)
    window.geometry('%dx%d+%d+%d' % (width, height, x, y))


center_window(700, 400)
window.config(highlightbackground="#053128",highlightthickness=5,highlightcolor="#053128")
window.mainloop()
